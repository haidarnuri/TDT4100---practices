package food;

public interface KitchenObserver {

public void informObserveres(String information);
}

