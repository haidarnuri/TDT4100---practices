Le Petite Chef - Oppgavekommentarer / Task comments
==========================
*For å skrive i denne filen trykker du på 'Markdown Source' nederst til venstre i denne fanen. For å se det fint trykker du på 'Preview'*

*To edit this file, press 'Markdown Source' in the bottom left of this 
Beskriv viktige valg du mener sensor bør vite om. Spar tid - vær kort og presis.
Describe important choices for the tasks you think should be known during evaluation. Save time - be short and precise!


## Oppgave 1 // task 1
**Example**

_IngredientContainer_
Not sure about how this one should use getters and setter. I chose to ...

## Oppgave 2 // task 2
*Your comments about task 2*

## Oppgave 3 // task 3
*Your comments about task 3*


## Oppgave 4 // task 4
*Your comments about task 4*


## Oppgave 5 // task 5
*Your comments about task 5*
