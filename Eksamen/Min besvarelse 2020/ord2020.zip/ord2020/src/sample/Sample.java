package sample;

public class Sample {

	public static String hello() {
		return "Hello";
	}

	public static void main(final String[] args) {
		System.out.println(hello());
	}
}
